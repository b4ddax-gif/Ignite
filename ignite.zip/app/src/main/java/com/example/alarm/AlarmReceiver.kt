package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.database.AppDatabase
import com.example.data.repository.HistoryRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class AlarmReceiver : BroadcastReceiver() {

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val alarmId = intent.getLongExtra(AlarmScheduler.EXTRA_ALARM_ID, -1L)
        val alarmLabel = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_LABEL) ?: "Alarm"
        val isSnooze = intent.getBooleanExtra(AlarmScheduler.EXTRA_IS_SNOOZE, false)
        val snoozeCount = intent.getIntExtra(AlarmScheduler.EXTRA_SNOOZE_COUNT, 0)

        Log.d("AlarmReceiver", "Received action $action for alarmId $alarmId")

        when (action) {
            AlarmScheduler.ACTION_TRIGGER_ALARM -> {
                // Start AlarmService foreground service
                val serviceIntent = Intent(context, AlarmService::class.java).apply {
                    this.action = AlarmService.ACTION_START_ALARM
                    putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarmId)
                    putExtra(AlarmScheduler.EXTRA_ALARM_LABEL, alarmLabel)
                    putExtra(AlarmScheduler.EXTRA_IS_SNOOZE, isSnooze)
                    putExtra(AlarmScheduler.EXTRA_SNOOZE_COUNT, snoozeCount)
                }
                ContextCompat.startForegroundService(context, serviceIntent)
            }

            AlarmScheduler.ACTION_SNOOZE_ALARM -> {
                // Stop service
                val stopIntent = Intent(context, AlarmService::class.java).apply {
                    this.action = AlarmService.ACTION_STOP_ALARM
                }
                context.startService(stopIntent)

                // Schedule snooze
                scope.launch {
                    val db = AppDatabase.getDatabase(context)
                    val alarm = db.alarmDao().getAlarmById(alarmId)
                    if (alarm != null) {
                        val newSnoozeCount = snoozeCount + 1
                        val scheduler = AlarmScheduler(context)
                        scheduler.scheduleSnooze(alarm, alarm.snoozeDuration, newSnoozeCount)

                        val historyRepo = HistoryRepository(db.alarmHistoryDao(), db.streakDao())
                        val todayStr = LocalDate.now().toString()
                        val timeStr = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
                        historyRepo.recordAlarmSnoozed(
                            alarmId = alarm.id,
                            alarmLabel = alarm.label,
                            scheduledDate = todayStr,
                            scheduledTime = timeStr,
                            snoozeCount = newSnoozeCount
                        )
                    }
                }
            }

            AlarmScheduler.ACTION_DISMISS_ALARM -> {
                // Stop service
                val stopIntent = Intent(context, AlarmService::class.java).apply {
                    this.action = AlarmService.ACTION_STOP_ALARM
                }
                context.startService(stopIntent)

                scope.launch {
                    val db = AppDatabase.getDatabase(context)
                    val alarm = db.alarmDao().getAlarmById(alarmId)
                    if (alarm != null) {
                        val historyRepo = HistoryRepository(db.alarmHistoryDao(), db.streakDao())
                        val todayStr = LocalDate.now().toString()
                        val timeStr = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
                        val dismissMethod = intent.getStringExtra("EXTRA_DISMISS_METHOD") ?: "NORMAL"

                        historyRepo.recordAlarmDismissed(
                            alarmId = alarm.id,
                            alarmLabel = alarm.label,
                            scheduledDate = todayStr,
                            scheduledTime = timeStr,
                            snoozeCount = snoozeCount,
                            dismissMethod = dismissMethod
                        )

                        // If alarm is one-time or date-specific, disable it.
                        // If repeating, reschedule next occurrence!
                        val isRepeating = alarm.repeatDays.isNotBlank() && alarm.specificDate.isNullOrBlank()
                        if (isRepeating) {
                            val scheduler = AlarmScheduler(context)
                            scheduler.scheduleAlarm(alarm)
                        } else {
                            db.alarmDao().updateAlarm(alarm.copy(enabled = false))
                        }
                    }
                }
            }
        }
    }
}
