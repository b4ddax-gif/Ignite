package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic Charcoal Black & Flame Accent Palette
val IgniteBackground = Color(0xFF0B0C0E)
val IgniteSurface = Color(0xFF14161B)
val IgniteSurfaceVariant = Color(0xFF1D2028)
val IgniteSurfaceBright = Color(0xFF262A36)

val IgniteFlamePrimary = Color(0xFFFF5722)
val IgniteFlameOrange = Color(0xFFFF7A00)
val IgniteFlameCrimson = Color(0xFFE63946)
val IgniteFlameContainer = Color(0xFF2A1510)
val IgniteFlameGlow = Color(0x33FF5722)

val IgniteTextPrimary = Color(0xFFF6F7F9)
val IgniteTextSecondary = Color(0xFF9DA3B4)
val IgniteTextMuted = Color(0xFF656B7D)

val IgniteOutline = Color(0xFF2B303D)
val IgniteOutlineSubtle = Color(0xFF1B1E26)

val PriorityHigh = Color(0xFFFF453A)
val PriorityMedium = Color(0xFFFF9F0A)
val PriorityLow = Color(0xFF30D158)
