package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val hour: Int,
    val minute: Int,
    val enabled: Boolean = true,
    val label: String = "Alarm",
    val repeatDays: String = "", // Comma-separated day numbers: 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat, 7=Sun or empty for once
    val specificDate: String? = null, // "yyyy-MM-dd" or null
    val soundUri: String? = null, // URI string from phone storage or null for built-in
    val soundName: String = "Ignite Pulse",
    val vibrationEnabled: Boolean = true,
    val gradualVolumeEnabled: Boolean = false,
    val snoozeEnabled: Boolean = true,
    val snoozeDuration: Int = 10, // minutes
    val maxSnoozeCount: Int = 3,
    val snoozeCount: Int = 0, // track current snooze streak for ringing cycle
    val missionType: String = "NORMAL", // NORMAL, MATH, SHAKE, QR
    val missionConfiguration: String = "", // e.g. shake count "15", math level "EASY", or registered QR text
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
