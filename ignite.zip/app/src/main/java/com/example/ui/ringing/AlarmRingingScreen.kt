package com.example.ui.ringing

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.IgniteApplication
import com.example.data.database.AlarmEntity
import com.example.ui.components.IgniteCard
import com.example.ui.components.IgniteDigitalClock
import com.example.ui.components.IgniteLogoHeader
import com.example.ui.theme.IgniteBackground
import com.example.ui.theme.IgniteFlameContainer
import com.example.ui.theme.IgniteFlameCrimson
import com.example.ui.theme.IgniteFlameOrange
import com.example.ui.theme.IgniteFlamePrimary
import com.example.ui.theme.IgniteSurface
import com.example.ui.theme.IgniteSurfaceVariant
import com.example.ui.theme.IgniteTextMuted
import com.example.ui.theme.IgniteTextPrimary
import com.example.ui.theme.IgniteTextSecondary
import com.google.zxing.BinaryBitmap
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import kotlin.math.sqrt
import kotlin.random.Random

@Composable
fun AlarmRingingScreen(
    alarmId: Long,
    alarmLabel: String,
    snoozeCount: Int,
    onDismiss: (String) -> Unit,
    onSnooze: () -> Unit
) {
    val context = LocalContext.current
    var alarm by remember { mutableStateOf<AlarmEntity?>(null) }

    LaunchedEffect(alarmId) {
        withContext(Dispatchers.IO) {
            val db = IgniteApplication.instance.database
            alarm = db.alarmDao().getAlarmById(alarmId)
        }
    }

    val missionType = alarm?.missionType ?: "NORMAL"
    val missionConfig = alarm?.missionConfiguration ?: ""
    val snoozeEnabled = alarm?.snoozeEnabled ?: true
    val maxSnooze = alarm?.maxSnoozeCount ?: 3
    val canSnooze = snoozeEnabled && (snoozeCount < maxSnooze)

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(IgniteBackground)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top: Branding & Glowing Flame
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .scale(pulseGlow)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(IgniteFlameOrange, IgniteFlamePrimary, IgniteFlameCrimson)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = "Ignite Ringing",
                        tint = Color.White,
                        modifier = Modifier.size(44.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "IGNITE",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 4.sp
                    ),
                    color = IgniteFlameOrange
                )

                Text(
                    text = alarmLabel,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = IgniteTextPrimary
                )

                Text(
                    text = "Sound: ${alarm?.soundName ?: "Ignite Pulse"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = IgniteTextMuted
                )
            }

            // Center: Big Live Clock
            IgniteDigitalClock(
                modifier = Modifier.fillMaxWidth()
            )

            // Mission Challenge Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                when (missionType) {
                    "MATH" -> {
                        MathMissionView(
                            onSolved = { onDismiss("MATH") }
                        )
                    }
                    "SHAKE" -> {
                        val targetShakes = missionConfig.toIntOrNull() ?: 15
                        ShakeMissionView(
                            targetShakes = targetShakes,
                            onComplete = { onDismiss("SHAKE") }
                        )
                    }
                    "QR" -> {
                        QrMissionView(
                            registeredCode = missionConfig,
                            onMatched = { onDismiss("QR") }
                        )
                    }
                    else -> {
                        NormalDismissView(
                            onDismiss = { onDismiss("NORMAL") }
                        )
                    }
                }
            }

            // Bottom Actions: Snooze & Dismiss Mission Info
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (snoozeEnabled) {
                    Button(
                        onClick = onSnooze,
                        enabled = canSnooze,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = IgniteSurfaceVariant,
                            contentColor = if (canSnooze) IgniteTextPrimary else IgniteTextMuted
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    ) {
                        Icon(Icons.Default.Snooze, contentDescription = null, tint = IgniteFlameOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (canSnooze) {
                                "Snooze ${alarm?.snoozeDuration ?: 10}m ($snoozeCount/$maxSnooze)"
                            } else {
                                "Max snoozes reached ($maxSnooze/$maxSnooze)"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NormalDismissView(onDismiss: () -> Unit) {
    Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = IgniteFlamePrimary),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
    ) {
        Text(
            text = "DISMISS ALARM",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp
            ),
            color = Color.White
        )
    }
}

@Composable
private fun MathMissionView(onSolved: () -> Unit) {
    var num1 by remember { mutableIntStateOf(Random.nextInt(12, 45)) }
    var num2 by remember { mutableIntStateOf(Random.nextInt(6, 35)) }
    val operation by remember { mutableStateOf(if (Random.nextBoolean()) "+" else "×") }
    val expectedAnswer = remember(num1, num2, operation) {
        if (operation == "+") num1 + num2 else (num1 % 12 + 2) * (num2 % 9 + 2)
    }
    val displayOp = remember(operation, num1, num2) {
        if (operation == "+") "$num1 + $num2" else "${num1 % 12 + 2} × ${num2 % 9 + 2}"
    }

    var userInput by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }

    IgniteCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = IgniteSurfaceVariant
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Calculate, contentDescription = null, tint = IgniteFlameOrange)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Solve to Dismiss", style = MaterialTheme.typography.titleSmall, color = IgniteFlameOrange)
            }

            Text(
                text = "$displayOp = ?",
                style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black),
                color = IgniteTextPrimary
            )

            Text(
                text = if (userInput.isEmpty()) "Enter answer" else userInput,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                ),
                color = if (isError) IgniteFlameCrimson else IgniteTextPrimary
            )

            // Number pad
            val rows = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("C", "0", "OK")
            )

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                rows.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        row.forEach { key ->
                            Button(
                                onClick = {
                                    isError = false
                                    when (key) {
                                        "C" -> userInput = ""
                                        "OK" -> {
                                            val entered = userInput.toIntOrNull()
                                            if (entered == expectedAnswer) {
                                                onSolved()
                                            } else {
                                                isError = true
                                                userInput = ""
                                            }
                                        }
                                        else -> if (userInput.length < 5) userInput += key
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (key == "OK") IgniteFlamePrimary else IgniteSurface
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            ) {
                                Text(
                                    text = key,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (key == "OK") Color.White else IgniteTextPrimary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShakeMissionView(
    targetShakes: Int,
    onComplete: () -> Unit
) {
    val context = LocalContext.current
    var remainingShakes by remember { mutableIntStateOf(targetShakes) }
    var lastX by remember { mutableStateOf(0f) }
    var lastY by remember { mutableStateOf(0f) }
    var lastZ by remember { mutableStateOf(0f) }
    var lastUpdate by remember { mutableStateOf(0L) }

    DisposableEffect(Unit) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event == null) return
                val curTime = System.currentTimeMillis()
                if ((curTime - lastUpdate) > 100) {
                    val diffTime = curTime - lastUpdate
                    lastUpdate = curTime

                    val x = event.values[0]
                    val y = event.values[1]
                    val z = event.values[2]

                    val speed = Math.abs(x + y + z - lastX - lastY - lastZ) / diffTime * 10000

                    if (speed > 800) { // Shake detected
                        if (remainingShakes > 1) {
                            remainingShakes -= 1
                        } else {
                            remainingShakes = 0
                            onComplete()
                        }
                    }

                    lastX = x
                    lastY = y
                    lastZ = z
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        accelerometer?.let {
            sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_GAME)
        }

        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }

    IgniteCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = IgniteSurfaceVariant
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Vibration,
                contentDescription = null,
                tint = IgniteFlamePrimary,
                modifier = Modifier.size(48.dp)
            )

            Text(
                text = "Shake Your Phone!",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = IgniteTextPrimary
            )

            Text(
                text = "$remainingShakes shakes left",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                ),
                color = IgniteFlameOrange
            )

            val progress = (targetShakes - remainingShakes).toFloat() / targetShakes.coerceAtLeast(1)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(IgniteSurface)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(
                            Brush.horizontalGradient(listOf(IgniteFlameOrange, IgniteFlamePrimary))
                        )
                )
            }
        }
    }
}

@Composable
private fun QrMissionView(
    registeredCode: String,
    onMatched: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasScannedMatch by remember { mutableStateOf(false) }
    var scanError by remember { mutableStateOf<String?>(null) }

    IgniteCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = IgniteSurfaceVariant
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = IgniteFlameOrange)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Scan QR Code to Dismiss",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = IgniteFlameOrange
                )
            }

            Box(
                modifier = Modifier
                    .size(200.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    factory = { ctx ->
                        val previewView = PreviewView(ctx)
                        val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                        cameraProviderFuture.addListener({
                            try {
                                val cameraProvider = cameraProviderFuture.get()
                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }

                                val imageAnalysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()

                                val reader = MultiFormatReader()

                                imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(ctx)) { imageProxy ->
                                    val planes = imageProxy.planes
                                    if (planes.isNotEmpty() && !hasScannedMatch) {
                                        val buffer = planes[0].buffer
                                        val data = ByteArray(buffer.remaining())
                                        buffer.get(data)
                                        val width = imageProxy.width
                                        val height = imageProxy.height

                                        val source = PlanarYUVLuminanceSource(
                                            data, width, height, 0, 0, width, height, false
                                        )
                                        val bitmap = BinaryBitmap(HybridBinarizer(source))

                                        try {
                                            val result = reader.decodeWithState(bitmap)
                                            val scannedText = result.text
                                            if (registeredCode.isBlank() || scannedText.contains(registeredCode)) {
                                                hasScannedMatch = true
                                                onMatched()
                                            }
                                        } catch (e: Exception) {
                                            // No QR code found in this frame
                                        } finally {
                                            reader.reset()
                                        }
                                    }
                                    imageProxy.close()
                                }

                                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                                cameraProvider.unbindAll()
                                cameraProvider.bindToLifecycle(
                                    lifecycleOwner,
                                    cameraSelector,
                                    preview,
                                    imageAnalysis
                                )
                            } catch (e: Exception) {
                                scanError = e.message
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Scanning frame
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .border(2.dp, IgniteFlamePrimary, RoundedCornerShape(12.dp))
                )
            }

            Text(
                text = if (registeredCode.isNotBlank()) "Target: $registeredCode" else "Scan any QR code",
                style = MaterialTheme.typography.bodySmall,
                color = IgniteTextMuted
            )

            // Manual bypass button for testing or camera failure
            OutlinedButton(
                onClick = onMatched,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = IgniteFlameOrange)
            ) {
                Text("Bypass Scan (Emergency)")
            }
        }
    }
}
