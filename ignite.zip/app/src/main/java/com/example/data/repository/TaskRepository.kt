package com.example.data.repository

import com.example.data.database.TaskDao
import com.example.data.database.TaskEntity
import kotlinx.coroutines.flow.Flow

class TaskRepository(private val taskDao: TaskDao) {
    val allTasks: Flow<List<TaskEntity>> = taskDao.getAllTasksFlow()

    fun getTasksForDate(date: String): Flow<List<TaskEntity>> =
        taskDao.getTasksForDateFlow(date)

    suspend fun insertTask(task: TaskEntity): Long =
        taskDao.insertTask(task)

    suspend fun updateTask(task: TaskEntity) =
        taskDao.updateTask(task)

    suspend fun setTaskCompleted(id: Long, completed: Boolean) =
        taskDao.setTaskCompleted(id, completed)

    suspend fun deleteTaskById(id: Long) =
        taskDao.deleteTaskById(id)
}
