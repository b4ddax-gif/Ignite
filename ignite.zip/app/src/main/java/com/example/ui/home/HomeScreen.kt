package com.example.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.IgniteCard
import com.example.ui.components.IgniteDigitalClock
import com.example.ui.components.IgniteLogoHeader
import com.example.ui.components.PriorityBadge
import com.example.ui.components.TimeFormatter
import com.example.ui.theme.IgniteBackground
import com.example.ui.theme.IgniteFlameContainer
import com.example.ui.theme.IgniteFlameCrimson
import com.example.ui.theme.IgniteFlameOrange
import com.example.ui.theme.IgniteFlamePrimary
import com.example.ui.theme.IgniteOutline
import com.example.ui.theme.IgniteSurface
import com.example.ui.theme.IgniteSurfaceVariant
import com.example.ui.theme.IgniteTextMuted
import com.example.ui.theme.IgniteTextPrimary
import com.example.ui.theme.IgniteTextSecondary
import java.time.LocalTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToAlarms: () -> Unit,
    onNavigateToCalendar: () -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    var showQuickAlarmDialog by remember { mutableStateOf(false) }
    var showQuickEventDialog by remember { mutableStateOf(false) }
    var showQuickTaskDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(IgniteBackground)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // App Brand Header
        item {
            IgniteLogoHeader(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            )
        }

        // Clock & Greeting Card
        item {
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = uiState.greeting,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = IgniteFlameOrange
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = uiState.currentDateFormatted,
                        style = MaterialTheme.typography.bodySmall,
                        color = IgniteTextSecondary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    IgniteDigitalClock(
                        modifier = Modifier.fillMaxWidth(),
                        is24Hour = uiState.is24Hour
                    )
                }
            }
        }

        // Wake Streak & Next Alarm Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Wake Streak Card
                IgniteCard(
                    modifier = Modifier.weight(1f),
                    backgroundColor = IgniteSurfaceVariant
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Streak",
                                tint = IgniteFlamePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "STREAK",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                color = IgniteFlamePrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "${uiState.streak.currentStreak}",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Black
                                ),
                                color = IgniteTextPrimary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "days",
                                style = MaterialTheme.typography.bodySmall,
                                color = IgniteTextSecondary,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Best: ${uiState.streak.longestStreak} • Total: ${uiState.streak.totalAlarmsCompleted}",
                            style = MaterialTheme.typography.labelSmall,
                            color = IgniteTextMuted
                        )
                    }
                }

                // Next Alarm Card
                IgniteCard(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToAlarms() },
                    backgroundColor = IgniteSurfaceVariant
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Alarm,
                                contentDescription = "Next Alarm",
                                tint = IgniteFlameOrange,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "NEXT ALARM",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                color = IgniteFlameOrange
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        if (uiState.nextAlarm != null) {
                            Text(
                                text = TimeFormatter.formatTime(
                                    uiState.nextAlarm!!.hour,
                                    uiState.nextAlarm!!.minute,
                                    uiState.is24Hour
                                ),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                color = IgniteTextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = uiState.nextAlarmCountdown,
                                style = MaterialTheme.typography.labelSmall,
                                color = IgniteFlamePrimary
                            )
                        } else {
                            Text(
                                text = "None set",
                                style = MaterialTheme.typography.titleMedium,
                                color = IgniteTextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tap to create",
                                style = MaterialTheme.typography.labelSmall,
                                color = IgniteTextMuted
                            )
                        }
                    }
                }
            }
        }

        // Quick Add Actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionButton(
                    icon = Icons.Default.Alarm,
                    label = "+ Alarm",
                    modifier = Modifier.weight(1f),
                    onClick = { showQuickAlarmDialog = true }
                )
                QuickActionButton(
                    icon = Icons.Default.Event,
                    label = "+ Event",
                    modifier = Modifier.weight(1f),
                    onClick = { showQuickEventDialog = true }
                )
                QuickActionButton(
                    icon = Icons.Default.TaskAlt,
                    label = "+ Task",
                    modifier = Modifier.weight(1f),
                    onClick = { showQuickTaskDialog = true }
                )
            }
        }

        // Unified Today Timeline Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TODAY'S TIMELINE",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    ),
                    color = IgniteTextSecondary
                )
                Text(
                    text = "${uiState.timelineItems.size} items",
                    style = MaterialTheme.typography.labelSmall,
                    color = IgniteTextMuted
                )
            }
        }

        if (uiState.timelineItems.isEmpty()) {
            item {
                IgniteCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = IgniteSurface
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = null,
                            tint = IgniteTextMuted,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No scheduled items for today",
                            style = MaterialTheme.typography.bodyMedium,
                            color = IgniteTextSecondary
                        )
                        Text(
                            text = "Use Quick Add to plan your day",
                            style = MaterialTheme.typography.bodySmall,
                            color = IgniteTextMuted
                        )
                    }
                }
            }
        } else {
            items(uiState.timelineItems, key = { it.id }) { item ->
                TimelineCard(item = item)
            }
        }

        // Daily Planner Checklist Section
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TODAY'S TASKS",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    ),
                    color = IgniteTextSecondary
                )
                Text(
                    text = "${uiState.todayTasks.count { it.completed }} / ${uiState.todayTasks.size} done",
                    style = MaterialTheme.typography.labelSmall,
                    color = IgniteFlameOrange
                )
            }
        }

        if (uiState.todayTasks.isEmpty()) {
            item {
                IgniteCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = IgniteSurface
                ) {
                    Text(
                        text = "No tasks yet. Stay focused and conquer the day.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = IgniteTextMuted,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            }
        } else {
            items(uiState.todayTasks, key = { it.id }) { task ->
                TaskRowItem(
                    task = task,
                    onToggle = { viewModel.toggleTask(task.id, !task.completed) }
                )
            }
        }
    }

    // Quick Add Alarm Dialog
    if (showQuickAlarmDialog) {
        QuickAddAlarmDialog(
            is24Hour = uiState.is24Hour,
            onDismiss = { showQuickAlarmDialog = false },
            onConfirm = { hour, minute, label ->
                viewModel.quickAddAlarm(hour, minute, label)
                showQuickAlarmDialog = false
            }
        )
    }

    // Quick Add Event Dialog
    if (showQuickEventDialog) {
        QuickAddEventDialog(
            onDismiss = { showQuickEventDialog = false },
            onConfirm = { title, time ->
                viewModel.quickAddEvent(title, time)
                showQuickEventDialog = false
            }
        )
    }

    // Quick Add Task Dialog
    if (showQuickTaskDialog) {
        QuickAddTaskDialog(
            onDismiss = { showQuickTaskDialog = false },
            onConfirm = { title, priority ->
                viewModel.quickAddTask(title, priority)
                showQuickTaskDialog = false
            }
        )
    }
}

@Composable
private fun QuickActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = IgniteSurfaceVariant,
            contentColor = IgniteTextPrimary
        )
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = IgniteFlamePrimary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun TimelineCard(item: TimelineItem) {
    val indicatorColor = when (item.type) {
        TimelineType.ALARM -> IgniteFlamePrimary
        TimelineType.EVENT -> IgniteFlameOrange
        TimelineType.TASK -> Color(0xFF38EF7D)
    }

    IgniteCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = IgniteSurface
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(indicatorColor)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = item.time,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = indicatorColor,
                modifier = Modifier.width(76.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.SemiBold,
                        textDecoration = if (item.completed) TextDecoration.LineThrough else TextDecoration.None
                    ),
                    color = if (item.completed) IgniteTextMuted else IgniteTextPrimary
                )
                Text(
                    text = item.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = IgniteTextMuted
                )
            }
        }
    }
}

@Composable
private fun TaskRowItem(
    task: com.example.data.database.TaskEntity,
    onToggle: () -> Unit
) {
    IgniteCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() },
        backgroundColor = IgniteSurface
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onToggle,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = if (task.completed) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = if (task.completed) "Mark incomplete" else "Mark complete",
                    tint = if (task.completed) IgniteFlamePrimary else IgniteTextMuted
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Medium,
                        textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None
                    ),
                    color = if (task.completed) IgniteTextMuted else IgniteTextPrimary
                )
                if (task.reminderTime != null) {
                    Text(
                        text = "Reminder: ${task.reminderTime}",
                        style = MaterialTheme.typography.bodySmall,
                        color = IgniteFlameOrange
                    )
                }
            }
            PriorityBadge(priority = task.priority)
        }
    }
}

@Composable
private fun QuickAddAlarmDialog(
    is24Hour: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Int, Int, String) -> Unit
) {
    var hour by remember { mutableStateOf(7) }
    var minute by remember { mutableStateOf(0) }
    var label by remember { mutableStateOf("Wake Up") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = IgniteSurfaceVariant,
        title = {
            Text("Quick Add Alarm", color = IgniteTextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Simple hour/minute selector
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Hour (0-23)", color = IgniteTextSecondary, style = MaterialTheme.typography.labelSmall)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { hour = if (hour > 0) hour - 1 else 23 }) {
                                Text("-", color = IgniteFlamePrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                String.format("%02d", hour),
                                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                                color = IgniteTextPrimary
                            )
                            IconButton(onClick = { hour = if (hour < 23) hour + 1 else 0 }) {
                                Text("+", color = IgniteFlamePrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Text(":", fontSize = 32.sp, color = IgniteTextSecondary, fontWeight = FontWeight.Bold)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Minute (0-59)", color = IgniteTextSecondary, style = MaterialTheme.typography.labelSmall)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { minute = if (minute >= 5) minute - 5 else 55 }) {
                                Text("-", color = IgniteFlamePrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                String.format("%02d", minute),
                                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                                color = IgniteTextPrimary
                            )
                            IconButton(onClick = { minute = if (minute <= 50) minute + 5 else 0 }) {
                                Text("+", color = IgniteFlamePrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Alarm Label") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IgniteFlamePrimary,
                        unfocusedBorderColor = IgniteOutline,
                        focusedTextColor = IgniteTextPrimary,
                        unfocusedTextColor = IgniteTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(hour, minute, label) },
                colors = ButtonDefaults.buttonColors(containerColor = IgniteFlamePrimary)
            ) {
                Text("Save Alarm", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = IgniteTextSecondary)
            }
        }
    )
}

@Composable
private fun QuickAddEventDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("10:00") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = IgniteSurfaceVariant,
        title = {
            Text("Quick Add Event (Today)", color = IgniteTextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Event Title") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IgniteFlamePrimary,
                        unfocusedBorderColor = IgniteOutline,
                        focusedTextColor = IgniteTextPrimary,
                        unfocusedTextColor = IgniteTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    label = { Text("Time (HH:mm)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IgniteFlamePrimary,
                        unfocusedBorderColor = IgniteOutline,
                        focusedTextColor = IgniteTextPrimary,
                        unfocusedTextColor = IgniteTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title, time) },
                colors = ButtonDefaults.buttonColors(containerColor = IgniteFlamePrimary)
            ) {
                Text("Save Event", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = IgniteTextSecondary)
            }
        }
    )
}

@Composable
private fun QuickAddTaskDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("MEDIUM") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = IgniteSurfaceVariant,
        title = {
            Text("Quick Add Task", color = IgniteTextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Description") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IgniteFlamePrimary,
                        unfocusedBorderColor = IgniteOutline,
                        focusedTextColor = IgniteTextPrimary,
                        unfocusedTextColor = IgniteTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Priority", color = IgniteTextSecondary, style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("LOW", "MEDIUM", "HIGH").forEach { p ->
                        val selected = priority == p
                        FilledTonalButton(
                            onClick = { priority = p },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (selected) IgniteFlamePrimary else IgniteSurface,
                                contentColor = if (selected) Color.White else IgniteTextSecondary
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(p, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title, priority) },
                colors = ButtonDefaults.buttonColors(containerColor = IgniteFlamePrimary)
            ) {
                Text("Add Task", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = IgniteTextSecondary)
            }
        }
    )
}
