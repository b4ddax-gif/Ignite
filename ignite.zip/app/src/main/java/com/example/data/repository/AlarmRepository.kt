package com.example.data.repository

import com.example.data.database.AlarmDao
import com.example.data.database.AlarmEntity
import kotlinx.coroutines.flow.Flow

class AlarmRepository(private val alarmDao: AlarmDao) {
    val allAlarms: Flow<List<AlarmEntity>> = alarmDao.getAllAlarmsFlow()

    suspend fun getAlarm(id: Long): AlarmEntity? = alarmDao.getAlarmById(id)

    fun getAlarmFlow(id: Long): Flow<AlarmEntity?> = alarmDao.getAlarmByIdFlow(id)

    suspend fun getEnabledAlarms(): List<AlarmEntity> = alarmDao.getEnabledAlarms()

    suspend fun insertAlarm(alarm: AlarmEntity): Long = alarmDao.insertAlarm(alarm)

    suspend fun updateAlarm(alarm: AlarmEntity) = alarmDao.updateAlarm(alarm)

    suspend fun deleteAlarm(alarm: AlarmEntity) = alarmDao.deleteAlarm(alarm)

    suspend fun deleteAlarmById(id: Long) = alarmDao.deleteAlarmById(id)

    suspend fun toggleAlarm(id: Long, enabled: Boolean) {
        val existing = alarmDao.getAlarmById(id) ?: return
        alarmDao.updateAlarm(existing.copy(enabled = enabled, updatedAt = System.currentTimeMillis()))
    }
}
