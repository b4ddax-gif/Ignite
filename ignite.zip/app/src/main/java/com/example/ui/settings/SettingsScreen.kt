package com.example.ui.settings

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.IgniteApplication
import com.example.ui.components.IgniteCard
import com.example.ui.components.IgniteLogoHeader
import com.example.ui.theme.IgniteBackground
import com.example.ui.theme.IgniteFlameContainer
import com.example.ui.theme.IgniteFlameCrimson
import com.example.ui.theme.IgniteFlameOrange
import com.example.ui.theme.IgniteFlamePrimary
import com.example.ui.theme.IgniteOutline
import com.example.ui.theme.IgniteSurface
import com.example.ui.theme.IgniteSurfaceVariant
import com.example.ui.theme.IgniteTextMuted
import com.example.ui.theme.IgniteTextPrimary
import com.example.ui.theme.IgniteTextSecondary

class SettingsViewModel : ViewModel() {
    private val repo = IgniteApplication.instance.settingsRepository

    val theme = repo.theme
    val is24Hour = repo.is24Hour
    val defaultSoundName = repo.defaultSoundName
    val defaultVibration = repo.defaultVibration
    val defaultGradualVolume = repo.defaultGradualVolume
    val defaultSnoozeDuration = repo.defaultSnoozeDuration
    val defaultDismissMission = repo.defaultDismissMission
    val firstDayOfWeek = repo.firstDayOfWeek
    val defaultCalendarView = repo.defaultCalendarView
    val eventRemindersEnabled = repo.eventRemindersEnabled
    val taskRemindersEnabled = repo.taskRemindersEnabled

    fun setTheme(theme: String) = repo.setTheme(theme)
    fun setIs24Hour(value: Boolean) = repo.setIs24Hour(value)
    fun setDefaultSoundName(name: String) = repo.setDefaultSoundName(name)
    fun setDefaultVibration(value: Boolean) = repo.setDefaultVibration(value)
    fun setDefaultGradualVolume(value: Boolean) = repo.setDefaultGradualVolume(value)
    fun setDefaultSnoozeDuration(duration: Int) = repo.setDefaultSnoozeDuration(duration)
    fun setDefaultDismissMission(mission: String) = repo.setDefaultDismissMission(mission)
    fun setFirstDayOfWeek(day: Int) = repo.setFirstDayOfWeek(day)
    fun setDefaultCalendarView(view: String) = repo.setDefaultCalendarView(view)
    fun setEventRemindersEnabled(value: Boolean) = repo.setEventRemindersEnabled(value)
    fun setTaskRemindersEnabled(value: Boolean) = repo.setTaskRemindersEnabled(value)
}

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = viewModel()
) {
    val context = LocalContext.current
    val is24Hour by viewModel.is24Hour.collectAsStateWithLifecycle()
    val defaultVibration by viewModel.defaultVibration.collectAsStateWithLifecycle()
    val defaultGradualVolume by viewModel.defaultGradualVolume.collectAsStateWithLifecycle()
    val defaultSnoozeDuration by viewModel.defaultSnoozeDuration.collectAsStateWithLifecycle()
    val defaultDismissMission by viewModel.defaultDismissMission.collectAsStateWithLifecycle()
    val defaultSoundName by viewModel.defaultSoundName.collectAsStateWithLifecycle()
    val firstDayOfWeek by viewModel.firstDayOfWeek.collectAsStateWithLifecycle()
    val defaultCalendarView by viewModel.defaultCalendarView.collectAsStateWithLifecycle()
    val eventRemindersEnabled by viewModel.eventRemindersEnabled.collectAsStateWithLifecycle()
    val taskRemindersEnabled by viewModel.taskRemindersEnabled.collectAsStateWithLifecycle()

    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val canScheduleExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        alarmManager.canScheduleExactAlarms()
    } else {
        true
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(IgniteBackground)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SETTINGS",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                ),
                color = IgniteTextPrimary
            )
        }

        // Exact Alarm Permission Status
        if (!canScheduleExact) {
            item {
                IgniteCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = IgniteFlameContainer
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = IgniteFlameCrimson)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Exact Alarm Permission Required",
                                fontWeight = FontWeight.Bold,
                                color = IgniteFlamePrimary
                            )
                        }
                        Text(
                            text = "To guarantee alarms ring at the precise minute even when the device is asleep, enable 'Alarms & Reminders' permission.",
                            style = MaterialTheme.typography.bodySmall,
                            color = IgniteTextPrimary
                        )
                        Button(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                        data = Uri.parse("package:${context.packageName}")
                                    }
                                    context.startActivity(intent)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IgniteFlamePrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Grant Exact Alarm Permission", color = Color.White)
                        }
                    }
                }
            }
        }

        // GENERAL SECTION
        item {
            SectionHeader(icon = Icons.Default.Tune, title = "GENERAL ALARM PREFERENCES")
        }

        item {
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // 24 Hour Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("24-Hour Time Format", color = IgniteTextPrimary, fontWeight = FontWeight.Medium)
                            Text("e.g. 14:00 instead of 2:00 PM", style = MaterialTheme.typography.bodySmall, color = IgniteTextMuted)
                        }
                        Switch(
                            checked = is24Hour,
                            onCheckedChange = { viewModel.setIs24Hour(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = IgniteFlamePrimary,
                                checkedTrackColor = IgniteFlameContainer
                            )
                        )
                    }

                    HorizontalDivider(color = IgniteOutline)

                    // Default Vibration
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Default Vibration", color = IgniteTextPrimary, fontWeight = FontWeight.Medium)
                        Switch(
                            checked = defaultVibration,
                            onCheckedChange = { viewModel.setDefaultVibration(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = IgniteFlamePrimary,
                                checkedTrackColor = IgniteFlameContainer
                            )
                        )
                    }

                    HorizontalDivider(color = IgniteOutline)

                    // Default Gradual Volume
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Gradual Volume Ramp", color = IgniteTextPrimary, fontWeight = FontWeight.Medium)
                            Text("Start quietly and increase volume", style = MaterialTheme.typography.bodySmall, color = IgniteTextMuted)
                        }
                        Switch(
                            checked = defaultGradualVolume,
                            onCheckedChange = { viewModel.setDefaultGradualVolume(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = IgniteFlamePrimary,
                                checkedTrackColor = IgniteFlameContainer
                            )
                        )
                    }

                    HorizontalDivider(color = IgniteOutline)

                    // Default Dismiss Mission
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Default Dismiss Mission", color = IgniteTextPrimary, fontWeight = FontWeight.Medium)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("NORMAL" to "Tap", "MATH" to "Math", "SHAKE" to "Shake", "QR" to "QR").forEach { (type, label) ->
                                FilterChip(
                                    selected = defaultDismissMission == type,
                                    onClick = { viewModel.setDefaultDismissMission(type) },
                                    label = { Text(label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = IgniteFlameContainer,
                                        selectedLabelColor = IgniteFlameOrange
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = IgniteOutline)

                    // Default Snooze Duration
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Default Snooze Duration", color = IgniteTextPrimary, fontWeight = FontWeight.Medium)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(5, 10, 15, 30).forEach { mins ->
                                FilterChip(
                                    selected = defaultSnoozeDuration == mins,
                                    onClick = { viewModel.setDefaultSnoozeDuration(mins) },
                                    label = { Text("${mins}m") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = IgniteFlameContainer,
                                        selectedLabelColor = IgniteFlameOrange
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // CALENDAR SECTION
        item {
            SectionHeader(icon = Icons.Default.CalendarMonth, title = "CALENDAR PREFERENCES")
        }

        item {
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("First Day of Week", color = IgniteTextPrimary, fontWeight = FontWeight.Medium)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = firstDayOfWeek == 1,
                                onClick = { viewModel.setFirstDayOfWeek(1) },
                                label = { Text("Monday") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IgniteFlameContainer,
                                    selectedLabelColor = IgniteFlameOrange
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = firstDayOfWeek == 7,
                                onClick = { viewModel.setFirstDayOfWeek(7) },
                                label = { Text("Sunday") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IgniteFlameContainer,
                                    selectedLabelColor = IgniteFlameOrange
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    HorizontalDivider(color = IgniteOutline)

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Default Calendar View", color = IgniteTextPrimary, fontWeight = FontWeight.Medium)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("MONTH" to "Month", "WEEK" to "Week", "DAY" to "Day").forEach { (view, label) ->
                                FilterChip(
                                    selected = defaultCalendarView == view,
                                    onClick = { viewModel.setDefaultCalendarView(view) },
                                    label = { Text(label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = IgniteFlameContainer,
                                        selectedLabelColor = IgniteFlameOrange
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // NOTIFICATIONS SECTION
        item {
            SectionHeader(icon = Icons.Default.Notifications, title = "NOTIFICATIONS")
        }

        item {
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Event Reminders", color = IgniteTextPrimary, fontWeight = FontWeight.Medium)
                            Text("Alerts for scheduled calendar events", style = MaterialTheme.typography.bodySmall, color = IgniteTextMuted)
                        }
                        Switch(
                            checked = eventRemindersEnabled,
                            onCheckedChange = { viewModel.setEventRemindersEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = IgniteFlamePrimary,
                                checkedTrackColor = IgniteFlameContainer
                            )
                        )
                    }

                    HorizontalDivider(color = IgniteOutline)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Task Reminders", color = IgniteTextPrimary, fontWeight = FontWeight.Medium)
                            Text("Alerts for daily planner tasks", style = MaterialTheme.typography.bodySmall, color = IgniteTextMuted)
                        }
                        Switch(
                            checked = taskRemindersEnabled,
                            onCheckedChange = { viewModel.setTaskRemindersEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = IgniteFlamePrimary,
                                checkedTrackColor = IgniteFlameContainer
                            )
                        )
                    }
                }
            }
        }

        // PRIVACY GUARANTEE (MANDATORY EXACT STATEMENT)
        item {
            SectionHeader(icon = Icons.Default.Security, title = "PRIVACY GUARANTEE")
        }

        item {
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurfaceVariant
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "100% Offline & Private",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = IgniteFlameOrange
                    )
                    Text(
                        text = "IGNITE works locally on your device. No account is required. No AI is used. No personal data is sent to a server. Audio files remain on your device. Alarm, calendar, task and history data are stored locally.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = IgniteTextPrimary,
                        lineHeight = 22.sp
                    )
                }
            }
        }

        // ABOUT APP
        item {
            SectionHeader(icon = Icons.Default.Info, title = "ABOUT IGNITE")
        }

        item {
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IgniteLogoHeader(showTagline = true)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Version 1.0 • Build Native Android",
                        style = MaterialTheme.typography.labelSmall,
                        color = IgniteTextMuted
                    )
                    Text(
                        text = "Offline Alarm Clock, Calendar & Daily Planner",
                        style = MaterialTheme.typography.bodySmall,
                        color = IgniteTextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(top = 8.dp)
    ) {
        Icon(icon, contentDescription = null, tint = IgniteFlameOrange, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            ),
            color = IgniteTextSecondary
        )
    }
}
