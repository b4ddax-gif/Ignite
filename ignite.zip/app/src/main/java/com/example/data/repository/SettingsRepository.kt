package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ignite_settings", Context.MODE_PRIVATE)

    private val _theme = MutableStateFlow(prefs.getString("theme", "DARK") ?: "DARK")
    val theme: StateFlow<String> = _theme.asStateFlow()

    private val _is24Hour = MutableStateFlow(prefs.getBoolean("is_24_hour", false))
    val is24Hour: StateFlow<Boolean> = _is24Hour.asStateFlow()

    private val _defaultSoundName =
        MutableStateFlow(prefs.getString("default_sound_name", "Ignite Pulse") ?: "Ignite Pulse")
    val defaultSoundName: StateFlow<String> = _defaultSoundName.asStateFlow()

    private val _defaultVibration =
        MutableStateFlow(prefs.getBoolean("default_vibration", true))
    val defaultVibration: StateFlow<Boolean> = _defaultVibration.asStateFlow()

    private val _defaultGradualVolume =
        MutableStateFlow(prefs.getBoolean("default_gradual_volume", false))
    val defaultGradualVolume: StateFlow<Boolean> = _defaultGradualVolume.asStateFlow()

    private val _defaultSnoozeDuration =
        MutableStateFlow(prefs.getInt("default_snooze_duration", 10))
    val defaultSnoozeDuration: StateFlow<Int> = _defaultSnoozeDuration.asStateFlow()

    private val _defaultDismissMission =
        MutableStateFlow(prefs.getString("default_dismiss_mission", "NORMAL") ?: "NORMAL")
    val defaultDismissMission: StateFlow<String> = _defaultDismissMission.asStateFlow()

    private val _firstDayOfWeek =
        MutableStateFlow(prefs.getInt("first_day_of_week", 1)) // 1 = Monday
    val firstDayOfWeek: StateFlow<Int> = _firstDayOfWeek.asStateFlow()

    private val _defaultCalendarView =
        MutableStateFlow(prefs.getString("default_calendar_view", "MONTH") ?: "MONTH")
    val defaultCalendarView: StateFlow<String> = _defaultCalendarView.asStateFlow()

    private val _eventRemindersEnabled =
        MutableStateFlow(prefs.getBoolean("event_reminders_enabled", true))
    val eventRemindersEnabled: StateFlow<Boolean> = _eventRemindersEnabled.asStateFlow()

    private val _taskRemindersEnabled =
        MutableStateFlow(prefs.getBoolean("task_reminders_enabled", true))
    val taskRemindersEnabled: StateFlow<Boolean> = _taskRemindersEnabled.asStateFlow()

    fun setTheme(theme: String) {
        prefs.edit().putString("theme", theme).apply()
        _theme.value = theme
    }

    fun setIs24Hour(value: Boolean) {
        prefs.edit().putBoolean("is_24_hour", value).apply()
        _is24Hour.value = value
    }

    fun setDefaultSoundName(name: String) {
        prefs.edit().putString("default_sound_name", name).apply()
        _defaultSoundName.value = name
    }

    fun setDefaultVibration(value: Boolean) {
        prefs.edit().putBoolean("default_vibration", value).apply()
        _defaultVibration.value = value
    }

    fun setDefaultGradualVolume(value: Boolean) {
        prefs.edit().putBoolean("default_gradual_volume", value).apply()
        _defaultGradualVolume.value = value
    }

    fun setDefaultSnoozeDuration(duration: Int) {
        prefs.edit().putInt("default_snooze_duration", duration).apply()
        _defaultSnoozeDuration.value = duration
    }

    fun setDefaultDismissMission(mission: String) {
        prefs.edit().putString("default_dismiss_mission", mission).apply()
        _defaultDismissMission.value = mission
    }

    fun setFirstDayOfWeek(day: Int) {
        prefs.edit().putInt("first_day_of_week", day).apply()
        _firstDayOfWeek.value = day
    }

    fun setDefaultCalendarView(view: String) {
        prefs.edit().putString("default_calendar_view", view).apply()
        _defaultCalendarView.value = view
    }

    fun setEventRemindersEnabled(value: Boolean) {
        prefs.edit().putBoolean("event_reminders_enabled", value).apply()
        _eventRemindersEnabled.value = value
    }

    fun setTaskRemindersEnabled(value: Boolean) {
        prefs.edit().putBoolean("task_reminders_enabled", value).apply()
        _taskRemindersEnabled.value = value
    }
}
