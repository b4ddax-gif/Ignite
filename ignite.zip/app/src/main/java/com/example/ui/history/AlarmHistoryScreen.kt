package com.example.ui.history

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.IgniteApplication
import com.example.data.database.AlarmHistoryEntity
import com.example.data.database.StreakEntity
import com.example.ui.components.IgniteCard
import com.example.ui.theme.IgniteBackground
import com.example.ui.theme.IgniteFlameContainer
import com.example.ui.theme.IgniteFlameCrimson
import com.example.ui.theme.IgniteFlameOrange
import com.example.ui.theme.IgniteFlamePrimary
import com.example.ui.theme.IgniteSurface
import com.example.ui.theme.IgniteSurfaceVariant
import com.example.ui.theme.IgniteTextMuted
import com.example.ui.theme.IgniteTextPrimary
import com.example.ui.theme.IgniteTextSecondary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

data class HistoryUiState(
    val historyItems: List<AlarmHistoryEntity> = emptyList(),
    val streak: StreakEntity = StreakEntity(),
    val activeFilter: String = "ALL" // TODAY, WEEK, MONTH, ALL
)

class HistoryViewModel : ViewModel() {
    private val app = IgniteApplication.instance
    private val historyRepo = app.historyRepository
    private val _filter = MutableStateFlow("ALL")

    val uiState: StateFlow<HistoryUiState> = combine(
        historyRepo.allHistory,
        historyRepo.streakFlow,
        _filter
    ) { allHistory, streak, filter ->
        val today = LocalDate.now()
        val filtered = when (filter) {
            "TODAY" -> allHistory.filter { it.scheduledDate == today.toString() }
            "WEEK" -> {
                val weekAgo = today.minusDays(7).toString()
                allHistory.filter { it.scheduledDate >= weekAgo }
            }
            "MONTH" -> {
                val monthAgo = today.minusDays(30).toString()
                allHistory.filter { it.scheduledDate >= monthAgo }
            }
            else -> allHistory
        }
        HistoryUiState(
            historyItems = filtered,
            streak = streak ?: StreakEntity(),
            activeFilter = filter
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HistoryUiState()
    )

    fun setFilter(filter: String) {
        _filter.value = filter
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            historyRepo.clearAllHistory()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlarmHistoryScreen(
    onNavigateBack: () -> Unit,
    viewModel: HistoryViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = IgniteBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Alarm History",
                        fontWeight = FontWeight.Bold,
                        color = IgniteTextPrimary
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = IgniteTextPrimary
                        )
                    }
                },
                actions = {
                    if (uiState.historyItems.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearAllHistory() }) {
                            Icon(
                                Icons.Default.DeleteSweep,
                                contentDescription = "Clear History",
                                tint = IgniteTextMuted
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = IgniteBackground)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Wake Streak Summary Card
            item {
                IgniteCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = IgniteSurfaceVariant
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.LocalFireDepartment,
                                    contentDescription = null,
                                    tint = IgniteFlamePrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "WAKE STREAK",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    ),
                                    color = IgniteFlamePrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${uiState.streak.currentStreak} Days Consecutive",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black
                                ),
                                color = IgniteTextPrimary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Longest: ${uiState.streak.longestStreak} days",
                                style = MaterialTheme.typography.bodySmall,
                                color = IgniteTextSecondary
                            )
                            Text(
                                text = "Total Completed: ${uiState.streak.totalAlarmsCompleted}",
                                style = MaterialTheme.typography.bodySmall,
                                color = IgniteFlameOrange
                            )
                        }
                    }
                }
            }

            // Filter Chips
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("ALL" to "All", "TODAY" to "Today", "WEEK" to "This Week", "MONTH" to "This Month").forEach { (key, label) ->
                        FilterChip(
                            selected = uiState.activeFilter == key,
                            onClick = { viewModel.setFilter(key) },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IgniteFlameContainer,
                                selectedLabelColor = IgniteFlameOrange
                            )
                        )
                    }
                }
            }

            // List of History Entries
            if (uiState.historyItems.isEmpty()) {
                item {
                    IgniteCard(
                        modifier = Modifier.fillMaxWidth(),
                        backgroundColor = IgniteSurface
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.History,
                                contentDescription = null,
                                tint = IgniteTextMuted,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No alarm history for this period",
                                style = MaterialTheme.typography.bodyMedium,
                                color = IgniteTextSecondary
                            )
                        }
                    }
                }
            } else {
                items(uiState.historyItems, key = { it.id }) { item ->
                    HistoryItemCard(item = item)
                }
            }
        }
    }
}

@Composable
private fun HistoryItemCard(item: AlarmHistoryEntity) {
    val dismissedTimeFormatted = remember(item.dismissedAt) {
        val dt = Instant.ofEpochMilli(item.dismissedAt).atZone(ZoneId.systemDefault())
        dt.format(DateTimeFormatter.ofPattern("MMM d, yyyy • hh:mm a"))
    }

    IgniteCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = IgniteSurface
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (item.action == "DISMISSED") Icons.Default.CheckCircle else Icons.Default.Snooze,
                        contentDescription = null,
                        tint = if (item.action == "DISMISSED") IgniteFlamePrimary else IgniteFlameOrange,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = item.alarmLabel,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = IgniteTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Scheduled: ${item.scheduledTime} • Dismissed: $dismissedTimeFormatted",
                    style = MaterialTheme.typography.bodySmall,
                    color = IgniteTextSecondary
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "Method: ${item.dismissMethod} • Snoozes: ${item.snoozeCount}",
                    style = MaterialTheme.typography.labelSmall,
                    color = IgniteTextMuted
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (item.action == "DISMISSED") IgniteFlameContainer else IgniteSurfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = item.action,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = if (item.action == "DISMISSED") IgniteFlameOrange else IgniteTextSecondary
                )
            }
        }
    }
}
