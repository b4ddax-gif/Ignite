package com.example.ui.calendar

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.IgniteApplication
import com.example.alarm.AlarmTimeCalculator
import com.example.calendar.CalendarScheduler
import com.example.data.database.AlarmEntity
import com.example.data.database.CalendarEventEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit

data class DayScheduleItem(
    val id: String,
    val title: String,
    val time: String,
    val isAlarm: Boolean,
    val isImportant: Boolean,
    val note: String = ""
)

data class CountdownItem(
    val eventId: Long,
    val title: String,
    val targetDate: String,
    val daysRemaining: Long,
    val isToday: Boolean
)

data class CalendarUiState(
    val selectedDate: LocalDate = LocalDate.now(),
    val currentMonth: YearMonth = YearMonth.now(),
    val calendarView: String = "MONTH", // MONTH, WEEK, DAY
    val events: List<CalendarEventEntity> = emptyList(),
    val alarms: List<AlarmEntity> = emptyList(),
    val selectedDayEvents: List<CalendarEventEntity> = emptyList(),
    val selectedDayAlarms: List<AlarmEntity> = emptyList(),
    val importantCountdowns: List<CountdownItem> = emptyList(),
    val searchQuery: String = "",
    val activeFilter: String = "ALL", // ALL, EVENTS, ALARMS, IMPORTANT
    val is24Hour: Boolean = false
)

class CalendarViewModel : ViewModel() {

    private val app = IgniteApplication.instance
    private val calendarRepo = app.calendarRepository
    private val alarmRepo = app.alarmRepository
    private val calendarScheduler = app.calendarScheduler
    private val settingsRepo = app.settingsRepository

    private val _selectedDate = MutableStateFlow(LocalDate.now())
    private val _currentMonth = MutableStateFlow(YearMonth.now())
    private val _calendarView = MutableStateFlow("MONTH")
    private val _searchQuery = MutableStateFlow("")
    private val _activeFilter = MutableStateFlow("ALL")

    private data class CalendarControls(
        val selectedDate: LocalDate,
        val currentMonth: YearMonth,
        val view: String,
        val query: String,
        val filter: String
    )

    private val _calendarControls = combine(
        _selectedDate,
        _currentMonth,
        _calendarView,
        _searchQuery,
        _activeFilter
    ) { selectedDate, currentMonth, view, query, filter ->
        CalendarControls(selectedDate, currentMonth, view, query, filter)
    }

    val uiState: StateFlow<CalendarUiState> = combine(
        _calendarControls,
        calendarRepo.allEvents,
        alarmRepo.allAlarms,
        settingsRepo.is24Hour
    ) { controls, allEvents, allAlarms, is24Hour ->
        val selectedDate = controls.selectedDate
        val currentMonth = controls.currentMonth
        val view = controls.view
        val query = controls.query
        val filter = controls.filter
        val dateStr = selectedDate.toString()
        val today = LocalDate.now()

        // Filter events by query if search active
        val filteredEvents = if (query.isNotBlank()) {
            allEvents.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.description.contains(query, ignoreCase = true) ||
                it.note.contains(query, ignoreCase = true) ||
                it.date.contains(query)
            }
        } else {
            allEvents
        }

        // Selected day events
        val dayEvents = filteredEvents.filter { it.date == dateStr }

        // Selected day alarms
        val dow = selectedDate.dayOfWeek.value
        val dayAlarms = allAlarms.filter { alarm ->
            if (!alarm.specificDate.isNullOrBlank()) {
                alarm.specificDate == dateStr
            } else if (alarm.repeatDays.isNotBlank()) {
                AlarmTimeCalculator.parseRepeatDays(alarm.repeatDays).contains(dow)
            } else {
                // One-time alarm
                true
            }
        }

        // Calculate countdowns for starred/important events in future
        val countdowns = allEvents.filter { it.important }.mapNotNull { event ->
            try {
                val eventDate = LocalDate.parse(event.date)
                val daysLeft = ChronoUnit.DAYS.between(today, eventDate)
                if (daysLeft >= 0) {
                    CountdownItem(
                        eventId = event.id,
                        title = event.title,
                        targetDate = event.date,
                        daysRemaining = daysLeft,
                        isToday = daysLeft == 0L
                    )
                } else null
            } catch (e: Exception) {
                null
            }
        }.sortedBy { it.daysRemaining }

        CalendarUiState(
            selectedDate = selectedDate,
            currentMonth = currentMonth,
            calendarView = view,
            events = filteredEvents,
            alarms = allAlarms,
            selectedDayEvents = dayEvents,
            selectedDayAlarms = dayAlarms,
            importantCountdowns = countdowns,
            searchQuery = query,
            activeFilter = filter,
            is24Hour = is24Hour
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = CalendarUiState()
    )

    fun selectDate(date: LocalDate) {
        _selectedDate.value = date
        _currentMonth.value = YearMonth.from(date)
    }

    fun nextMonth() {
        _currentMonth.value = _currentMonth.value.plusMonths(1)
    }

    fun prevMonth() {
        _currentMonth.value = _currentMonth.value.minusMonths(1)
    }

    fun goToToday() {
        val today = LocalDate.now()
        _selectedDate.value = today
        _currentMonth.value = YearMonth.from(today)
    }

    fun setCalendarView(view: String) {
        _calendarView.value = view
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setActiveFilter(filter: String) {
        _activeFilter.value = filter
    }

    fun saveEvent(event: CalendarEventEntity, onSaved: () -> Unit) {
        viewModelScope.launch {
            if (event.id == 0L) {
                val newId = calendarRepo.insertEvent(event)
                calendarScheduler.scheduleEventReminder(event.copy(id = newId))
            } else {
                calendarRepo.updateEvent(event)
                calendarScheduler.scheduleEventReminder(event)
            }
            onSaved()
        }
    }

    fun deleteEvent(event: CalendarEventEntity) {
        viewModelScope.launch {
            calendarScheduler.cancelEventReminder(event.id)
            calendarRepo.deleteEvent(event)
        }
    }
}
