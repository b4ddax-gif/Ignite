package com.example.ui.alarms

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alarm.AlarmTimeCalculator
import com.example.data.database.AlarmEntity
import com.example.ui.components.IgniteCard
import com.example.ui.components.TimeFormatter
import com.example.ui.theme.IgniteBackground
import com.example.ui.theme.IgniteFlameContainer
import com.example.ui.theme.IgniteFlameOrange
import com.example.ui.theme.IgniteFlamePrimary
import com.example.ui.theme.IgniteOutline
import com.example.ui.theme.IgniteSurface
import com.example.ui.theme.IgniteSurfaceVariant
import com.example.ui.theme.IgniteTextMuted
import com.example.ui.theme.IgniteTextPrimary
import com.example.ui.theme.IgniteTextSecondary
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditAlarmSheet(
    alarm: AlarmEntity?,
    is24Hour: Boolean,
    onDismiss: () -> Unit,
    onSave: (AlarmEntity) -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var hour by remember { mutableIntStateOf(alarm?.hour ?: 7) }
    var minute by remember { mutableIntStateOf(alarm?.minute ?: 0) }
    var label by remember { mutableStateOf(alarm?.label ?: "Morning Alarm") }

    // Repeat Days: 1=Mon .. 7=Sun
    var selectedDays by remember {
        mutableStateOf(AlarmTimeCalculator.parseRepeatDays(alarm?.repeatDays ?: ""))
    }
    var specificDate by remember { mutableStateOf(alarm?.specificDate) }
    var showDatePicker by remember { mutableStateOf(false) }

    var vibration by remember { mutableStateOf(alarm?.vibrationEnabled ?: true) }
    var gradualVolume by remember { mutableStateOf(alarm?.gradualVolumeEnabled ?: false) }

    // Snooze
    var snoozeEnabled by remember { mutableStateOf(alarm?.snoozeEnabled ?: true) }
    var snoozeDuration by remember { mutableIntStateOf(alarm?.snoozeDuration ?: 10) }
    var maxSnoozeCount by remember { mutableIntStateOf(alarm?.maxSnoozeCount ?: 3) }

    // Sound
    var soundUri by remember { mutableStateOf(alarm?.soundUri) }
    var soundName by remember { mutableStateOf(alarm?.soundName ?: "Ignite Pulse") }
    var isPreviewPlaying by remember { mutableStateOf(false) }
    var previewPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    // Dismiss Mission: NORMAL, MATH, SHAKE, QR
    var missionType by remember { mutableStateOf(alarm?.missionType ?: "NORMAL") }
    var missionConfig by remember { mutableStateOf(alarm?.missionConfiguration ?: "") }

    // Audio file picker contract for SAF
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            AudioPickerHelper.persistUriPermission(context, uri)
            val name = AudioPickerHelper.getDisplayName(context, uri)
            soundUri = uri.toString()
            soundName = name
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            previewPlayer?.stop()
            previewPlayer?.release()
            previewPlayer = null
        }
    }

    fun togglePreviewSound() {
        if (isPreviewPlaying) {
            previewPlayer?.stop()
            previewPlayer?.release()
            previewPlayer = null
            isPreviewPlaying = false
        } else {
            try {
                val player = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    if (!soundUri.isNullOrBlank()) {
                        setDataSource(context, Uri.parse(soundUri))
                    } else {
                        val defaultUri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM)
                        setDataSource(context, defaultUri)
                    }
                    prepare()
                    start()
                }
                player.setOnCompletionListener {
                    isPreviewPlaying = false
                    player.release()
                    previewPlayer = null
                }
                previewPlayer = player
                isPreviewPlaying = true
            } catch (e: Exception) {
                isPreviewPlaying = false
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = IgniteBackground,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (alarm == null) "New Alarm" else "Edit Alarm",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = IgniteTextPrimary
                )
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = IgniteTextSecondary
                    )
                }
            }

            // Large Time Picker Card
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = TimeFormatter.formatTime(hour, minute, is24Hour),
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        ),
                        color = IgniteFlamePrimary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        // Hour Adjuster
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("HOUR", style = MaterialTheme.typography.labelSmall, color = IgniteTextSecondary)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Button(
                                    onClick = { hour = if (hour > 0) hour - 1 else 23 },
                                    colors = ButtonDefaults.buttonColors(containerColor = IgniteSurfaceVariant)
                                ) { Text("-", color = IgniteFlamePrimary, fontSize = 20.sp) }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    String.format("%02d", hour),
                                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                                    color = IgniteTextPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { hour = if (hour < 23) hour + 1 else 0 },
                                    colors = ButtonDefaults.buttonColors(containerColor = IgniteSurfaceVariant)
                                ) { Text("+", color = IgniteFlamePrimary, fontSize = 20.sp) }
                            }
                        }

                        // Minute Adjuster
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("MINUTE", style = MaterialTheme.typography.labelSmall, color = IgniteTextSecondary)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Button(
                                    onClick = { minute = if (minute >= 5) minute - 5 else 55 },
                                    colors = ButtonDefaults.buttonColors(containerColor = IgniteSurfaceVariant)
                                ) { Text("-", color = IgniteFlamePrimary, fontSize = 20.sp) }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    String.format("%02d", minute),
                                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                                    color = IgniteTextPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { minute = if (minute <= 50) minute + 5 else 0 },
                                    colors = ButtonDefaults.buttonColors(containerColor = IgniteSurfaceVariant)
                                ) { Text("+", color = IgniteFlamePrimary, fontSize = 20.sp) }
                            }
                        }
                    }
                }
            }

            // Alarm Label
            OutlinedTextField(
                value = label,
                onValueChange = { label = it },
                label = { Text("Alarm Name / Label") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IgniteFlamePrimary,
                    unfocusedBorderColor = IgniteOutline,
                    focusedTextColor = IgniteTextPrimary,
                    unfocusedTextColor = IgniteTextPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            // Repeat Days Section
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "REPEAT",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = IgniteTextSecondary
                    )
                    Text(
                        text = AlarmTimeCalculator.getRepeatDaysSummary(
                            AlarmTimeCalculator.formatRepeatDays(selectedDays),
                            specificDate
                        ),
                        style = MaterialTheme.typography.labelMedium,
                        color = IgniteFlameOrange
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val dayNames = listOf("M" to 1, "T" to 2, "W" to 3, "T" to 4, "F" to 5, "S" to 6, "S" to 7)
                    dayNames.forEach { (name, day) ->
                        val isSelected = selectedDays.contains(day)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) IgniteFlamePrimary else IgniteSurfaceVariant)
                                .clickable {
                                    specificDate = null // clear specific date if selecting repeat days
                                    selectedDays = if (isSelected) {
                                        selectedDays - day
                                    } else {
                                        selectedDays + day
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = name,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else IgniteTextSecondary
                            )
                        }
                    }
                }
            }

            // Specific Date Alarm Option
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = IgniteFlameOrange)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Specific Date Alarm",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = IgniteTextPrimary
                            )
                        }
                        if (specificDate != null) {
                            TextButton(onClick = { specificDate = null }) {
                                Text("Clear", color = IgniteFlamePrimary)
                            }
                        }
                    }

                    if (specificDate != null) {
                        Text(
                            text = "Scheduled for: $specificDate",
                            style = MaterialTheme.typography.bodyMedium,
                            color = IgniteFlameOrange
                        )
                    } else {
                        Text(
                            text = "Rings only on a specific calendar date (e.g. Dec 25)",
                            style = MaterialTheme.typography.bodySmall,
                            color = IgniteTextMuted
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val today = LocalDate.now()
                        val quickDates = listOf(
                            "Tomorrow" to today.plusDays(1).toString(),
                            "Next Week" to today.plusDays(7).toString()
                        )
                        quickDates.forEach { (title, dateStr) ->
                            FilterChip(
                                selected = specificDate == dateStr,
                                onClick = {
                                    specificDate = dateStr
                                    selectedDays = emptySet()
                                },
                                label = { Text(title) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IgniteFlameContainer,
                                    selectedLabelColor = IgniteFlameOrange
                                )
                            )
                        }
                    }
                }
            }

            // Sound Section: Custom Song from Phone + Built-in Sounds
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "ALARM SOUND",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = IgniteTextSecondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = soundName,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = IgniteFlameOrange,
                                maxLines = 1
                            )
                            Text(
                                text = if (soundUri != null) "Custom song from device" else "Built-in tone",
                                style = MaterialTheme.typography.bodySmall,
                                color = IgniteTextMuted
                            )
                        }
                        IconButton(onClick = { togglePreviewSound() }) {
                            Icon(
                                imageVector = if (isPreviewPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = "Preview sound",
                                tint = IgniteFlamePrimary
                            )
                        }
                    }

                    // Choose Custom Song Button
                    Button(
                        onClick = { audioPickerLauncher.launch(arrayOf("audio/*")) },
                        colors = ButtonDefaults.buttonColors(containerColor = IgniteSurfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AudioFile, contentDescription = null, tint = IgniteFlamePrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Choose Audio From Phone (MP3, WAV, M4A, OGG)", color = IgniteTextPrimary)
                    }

                    // Built-in presets
                    Text(
                        text = "Built-in Sound Presets",
                        style = MaterialTheme.typography.labelSmall,
                        color = IgniteTextMuted
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Ignite Pulse", "Aurora Beacon", "Dawn Ember", "Classic Bell").forEach { preset ->
                            val isSelected = soundUri == null && soundName == preset
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    soundUri = null
                                    soundName = preset
                                },
                                label = { Text(preset) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IgniteFlameContainer,
                                    selectedLabelColor = IgniteFlameOrange
                                )
                            )
                        }
                    }
                }
            }

            // Vibration & Gradual Volume
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Vibration, contentDescription = null, tint = IgniteFlameOrange)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Vibration", color = IgniteTextPrimary, fontWeight = FontWeight.Medium)
                        }
                        Switch(
                            checked = vibration,
                            onCheckedChange = { vibration = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = IgniteFlamePrimary, checkedTrackColor = IgniteFlameContainer)
                        )
                    }

                    HorizontalDivider(color = IgniteOutline)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = IgniteFlameOrange)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Gradual Volume", color = IgniteTextPrimary, fontWeight = FontWeight.Medium)
                                Text("Gently ramps up over 60s", style = MaterialTheme.typography.bodySmall, color = IgniteTextMuted)
                            }
                        }
                        Switch(
                            checked = gradualVolume,
                            onCheckedChange = { gradualVolume = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = IgniteFlamePrimary, checkedTrackColor = IgniteFlameContainer)
                        )
                    }
                }
            }

            // Snooze Settings
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Snooze", color = IgniteTextPrimary, fontWeight = FontWeight.SemiBold)
                        Switch(
                            checked = snoozeEnabled,
                            onCheckedChange = { snoozeEnabled = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = IgniteFlamePrimary, checkedTrackColor = IgniteFlameContainer)
                        )
                    }

                    if (snoozeEnabled) {
                        Text("Snooze Duration", style = MaterialTheme.typography.labelSmall, color = IgniteTextSecondary)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(5, 10, 15, 30).forEach { mins ->
                                FilterChip(
                                    selected = snoozeDuration == mins,
                                    onClick = { snoozeDuration = mins },
                                    label = { Text("${mins}m") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = IgniteFlameContainer,
                                        selectedLabelColor = IgniteFlameOrange
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Text("Max Snooze Count", style = MaterialTheme.typography.labelSmall, color = IgniteTextSecondary)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(1, 2, 3, 5).forEach { count ->
                                FilterChip(
                                    selected = maxSnoozeCount == count,
                                    onClick = { maxSnoozeCount = count },
                                    label = { Text("${count}x") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = IgniteFlameContainer,
                                        selectedLabelColor = IgniteFlameOrange
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // Dismiss Missions (NORMAL, MATH, SHAKE, QR)
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "DISMISS MISSION",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = IgniteTextSecondary
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val missions = listOf(
                            "NORMAL" to "Normal (Tap)",
                            "MATH" to "Math Problem",
                            "SHAKE" to "Shake Phone",
                            "QR" to "Scan QR Code"
                        )
                        missions.forEach { (type, title) ->
                            FilterChip(
                                selected = missionType == type,
                                onClick = {
                                    missionType = type
                                    if (type == "SHAKE" && missionConfig.isBlank()) missionConfig = "15"
                                    if (type == "QR" && missionConfig.isBlank()) missionConfig = "IGNITE_WAKE_UP"
                                },
                                label = { Text(title) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IgniteFlameContainer,
                                    selectedLabelColor = IgniteFlameOrange
                                )
                            )
                        }
                    }

                    when (missionType) {
                        "MATH" -> {
                            Text(
                                text = "A random arithmetic problem will be generated locally. Solve it to turn off the alarm.",
                                style = MaterialTheme.typography.bodySmall,
                                color = IgniteTextMuted
                            )
                        }
                        "SHAKE" -> {
                            Text(
                                text = "You must shake your phone rapidly to turn off the alarm.",
                                style = MaterialTheme.typography.bodySmall,
                                color = IgniteTextMuted
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("10", "15", "25").forEach { shakes ->
                                    FilterChip(
                                        selected = missionConfig == shakes,
                                        onClick = { missionConfig = shakes },
                                        label = { Text("$shakes Shakes") },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = IgniteFlameContainer,
                                            selectedLabelColor = IgniteFlameOrange
                                        )
                                    )
                                }
                            }
                        }
                        "QR" -> {
                            Text(
                                text = "Register a QR code payload below. When the alarm rings, scan this QR code to turn it off.",
                                style = MaterialTheme.typography.bodySmall,
                                color = IgniteTextMuted
                            )
                            OutlinedTextField(
                                value = missionConfig,
                                onValueChange = { missionConfig = it },
                                label = { Text("Registered QR Code text") },
                                placeholder = { Text("e.g. Bathroom Mug QR") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IgniteFlamePrimary,
                                    unfocusedBorderColor = IgniteOutline,
                                    focusedTextColor = IgniteTextPrimary,
                                    unfocusedTextColor = IgniteTextPrimary
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        else -> {
                            Text(
                                text = "Standard tap dismiss button.",
                                style = MaterialTheme.typography.bodySmall,
                                color = IgniteTextMuted
                            )
                        }
                    }
                }
            }

            // Save Alarm Button
            Button(
                onClick = {
                    val repeatDaysStr = AlarmTimeCalculator.formatRepeatDays(selectedDays)
                    val newAlarm = (alarm ?: AlarmEntity(hour = hour, minute = minute)).copy(
                        hour = hour,
                        minute = minute,
                        label = label.ifBlank { "Alarm" },
                        repeatDays = repeatDaysStr,
                        specificDate = specificDate,
                        soundUri = soundUri,
                        soundName = soundName,
                        vibrationEnabled = vibration,
                        gradualVolumeEnabled = gradualVolume,
                        snoozeEnabled = snoozeEnabled,
                        snoozeDuration = snoozeDuration,
                        maxSnoozeCount = maxSnoozeCount,
                        missionType = missionType,
                        missionConfiguration = missionConfig,
                        enabled = true,
                        updatedAt = System.currentTimeMillis()
                    )
                    onSave(newAlarm)
                },
                colors = ButtonDefaults.buttonColors(containerColor = IgniteFlamePrimary),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                Text(
                    text = "Save Alarm",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
