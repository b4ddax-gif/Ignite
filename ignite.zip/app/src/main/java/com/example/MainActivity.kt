package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.ui.alarms.AlarmsScreen
import com.example.ui.calendar.CalendarScreen
import com.example.ui.history.AlarmHistoryScreen
import com.example.ui.home.HomeScreen
import com.example.ui.navigation.Screen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.IGNITETheme
import com.example.ui.theme.IgniteBackground
import com.example.ui.theme.IgniteFlameContainer
import com.example.ui.theme.IgniteFlameOrange
import com.example.ui.theme.IgniteFlamePrimary
import com.example.ui.theme.IgniteSurface
import com.example.ui.theme.IgniteTextMuted
import com.example.ui.theme.IgniteTextPrimary
import com.example.ui.theme.IgniteTextSecondary

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            IGNITETheme(darkTheme = true) {
                MainAppContainer()
            }
        }
    }
}

enum class NavigationTab(val title: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    ALARMS("Alarms", Icons.Default.Alarm),
    CALENDAR("Calendar", Icons.Default.CalendarMonth),
    SETTINGS("Settings", Icons.Default.Settings)
}

@Composable
fun MainAppContainer() {
    val context = LocalContext.current
    var currentTab by remember { mutableStateOf(NavigationTab.HOME) }
    var showAlarmHistory by remember { mutableStateOf(false) }

    // Request POST_NOTIFICATIONS permission on Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* Permission granted or denied handled gracefully */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasPermission) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Handle back button when on sub-screen
    BackHandler(enabled = showAlarmHistory || currentTab != NavigationTab.HOME) {
        if (showAlarmHistory) {
            showAlarmHistory = false
        } else {
            currentTab = NavigationTab.HOME
        }
    }

    Scaffold(
        containerColor = IgniteBackground,
        bottomBar = {
            if (!showAlarmHistory) {
                NavigationBar(
                    containerColor = IgniteSurface,
                    tonalElevation = 8.dp
                ) {
                    NavigationTab.values().forEach { tab ->
                        val selected = currentTab == tab
                        NavigationBarItem(
                            selected = selected,
                            onClick = { currentTab = tab },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title
                                )
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = IgniteFlameOrange,
                                indicatorColor = IgniteFlamePrimary,
                                unselectedIconColor = IgniteTextMuted,
                                unselectedTextColor = IgniteTextMuted
                            )
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (showAlarmHistory) {
                AlarmHistoryScreen(
                    onNavigateBack = { showAlarmHistory = false }
                )
            } else {
                when (currentTab) {
                    NavigationTab.HOME -> {
                        HomeScreen(
                            onNavigateToAlarms = { currentTab = NavigationTab.ALARMS },
                            onNavigateToCalendar = { currentTab = NavigationTab.CALENDAR }
                        )
                    }
                    NavigationTab.ALARMS -> {
                        AlarmsScreen(
                            onNavigateToHistory = { showAlarmHistory = true }
                        )
                    }
                    NavigationTab.CALENDAR -> {
                        CalendarScreen()
                    }
                    NavigationTab.SETTINGS -> {
                        SettingsScreen()
                    }
                }
            }
        }
    }
}
