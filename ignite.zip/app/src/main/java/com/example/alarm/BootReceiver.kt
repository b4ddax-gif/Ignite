package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.calendar.CalendarScheduler
import com.example.data.database.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.d("BootReceiver", "Received action $action, restoring alarms and reminders")

        scope.launch {
            try {
                val db = AppDatabase.getDatabase(context)
                val alarmScheduler = AlarmScheduler(context)
                val calendarScheduler = CalendarScheduler(context)

                // 1. Reschedule enabled alarms
                val enabledAlarms = db.alarmDao().getEnabledAlarms()
                for (alarm in enabledAlarms) {
                    val nextTrigger = AlarmTimeCalculator.calculateNextTriggerTime(alarm)
                    if (nextTrigger > System.currentTimeMillis()) {
                        alarmScheduler.scheduleAlarm(alarm, nextTrigger)
                    } else if (!alarm.specificDate.isNullOrBlank()) {
                        // Expired specific-date alarm
                        db.alarmDao().updateAlarm(alarm.copy(enabled = false))
                    }
                }

                // 2. Reschedule calendar reminders
                val events = db.calendarEventDao().getAllEventsFlow()
                // In background we can query future events
                val todayStr = java.time.LocalDate.now().toString()
                val futureEvents = db.calendarEventDao().getEventsForDate(todayStr)
                for (event in futureEvents) {
                    if (event.reminder != "NONE") {
                        calendarScheduler.scheduleEventReminder(event)
                    }
                }
            } catch (e: Exception) {
                Log.e("BootReceiver", "Error restoring alarms/reminders on boot", e)
            }
        }
    }
}
