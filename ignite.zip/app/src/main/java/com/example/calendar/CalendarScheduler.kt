package com.example.calendar

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.database.CalendarEventEntity
import com.example.data.database.TaskEntity
import com.example.notifications.NotificationReceiver
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

class CalendarScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun scheduleEventReminder(event: CalendarEventEntity) {
        if (event.reminder == "NONE") {
            cancelEventReminder(event.id)
            return
        }

        val triggerMillis = calculateReminderTime(event)
        if (triggerMillis <= System.currentTimeMillis()) {
            return
        }

        val intent = Intent(context, NotificationReceiver::class.java).apply {
            action = NotificationReceiver.ACTION_EVENT_REMINDER
            putExtra(NotificationReceiver.EXTRA_EVENT_ID, event.id)
            putExtra(NotificationReceiver.EXTRA_TITLE, event.title)
            putExtra(NotificationReceiver.EXTRA_TIME, "${event.date} ${event.startTime}")
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            (EVENT_REQUEST_CODE_OFFSET + event.id).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
            }
        } catch (e: Exception) {
            Log.e("CalendarScheduler", "Error scheduling event reminder", e)
        }
    }

    fun cancelEventReminder(eventId: Long) {
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            action = NotificationReceiver.ACTION_EVENT_REMINDER
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            (EVENT_REQUEST_CODE_OFFSET + eventId).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    fun scheduleTaskReminder(task: TaskEntity) {
        if (task.completed || task.reminderTime.isNullOrBlank()) {
            cancelTaskReminder(task.id)
            return
        }

        val triggerMillis = try {
            val date = LocalDate.parse(task.date)
            val time = LocalTime.parse(task.reminderTime)
            date.atTime(time).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        } catch (e: Exception) {
            -1L
        }

        if (triggerMillis <= System.currentTimeMillis()) return

        val intent = Intent(context, NotificationReceiver::class.java).apply {
            action = NotificationReceiver.ACTION_TASK_REMINDER
            putExtra(NotificationReceiver.EXTRA_TASK_ID, task.id)
            putExtra(NotificationReceiver.EXTRA_TITLE, task.title)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            (TASK_REQUEST_CODE_OFFSET + task.id).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
        } catch (e: Exception) {
            Log.e("CalendarScheduler", "Error scheduling task reminder", e)
        }
    }

    fun cancelTaskReminder(taskId: Long) {
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            action = NotificationReceiver.ACTION_TASK_REMINDER
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            (TASK_REQUEST_CODE_OFFSET + taskId).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    companion object {
        private const val EVENT_REQUEST_CODE_OFFSET = 200000
        private const val TASK_REQUEST_CODE_OFFSET = 300000

        fun calculateReminderTime(event: CalendarEventEntity): Long {
            return try {
                val date = LocalDate.parse(event.date)
                val time = if (event.allDay) LocalTime.of(9, 0) else LocalTime.parse(event.startTime)
                val eventDateTime = date.atTime(time)
                val baseMillis = eventDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

                val minutesBefore = when (event.reminder) {
                    "5_MIN" -> 5
                    "10_MIN" -> 10
                    "15_MIN" -> 15
                    "30_MIN" -> 30
                    "1_HOUR" -> 60
                    "1_DAY" -> 1440
                    else -> 0
                }
                baseMillis - (minutesBefore * 60 * 1000L)
            } catch (e: Exception) {
                -1L
            }
        }
    }
}
