package com.example.alarm

import com.example.data.database.AlarmEntity
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object AlarmTimeCalculator {

    /**
     * Calculates the next epoch millisecond timestamp for the given alarm.
     * Returns -1 if the alarm is date-specific and in the past.
     */
    fun calculateNextTriggerTime(alarm: AlarmEntity, nowMillis: Long = System.currentTimeMillis()): Long {
        val zoneId = ZoneId.systemDefault()
        val now = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(nowMillis), zoneId)

        // 1. Specific Date Alarm
        if (!alarm.specificDate.isNullOrBlank()) {
            return try {
                val date = LocalDate.parse(alarm.specificDate)
                val targetDateTime = date.atTime(alarm.hour, alarm.minute)
                val targetMillis = targetDateTime.atZone(zoneId).toInstant().toEpochMilli()
                if (targetMillis > nowMillis) targetMillis else -1L
            } catch (e: Exception) {
                -1L
            }
        }

        // 2. Repeating Alarm (1=Monday ... 7=Sunday)
        val repeatDaysList = parseRepeatDays(alarm.repeatDays)
        if (repeatDaysList.isNotEmpty()) {
            for (dayOffset in 0..7) {
                val candidateDate = now.toLocalDate().plusDays(dayOffset.toLong())
                val dayOfWeekValue = candidateDate.dayOfWeek.value // 1 (Mon) - 7 (Sun)
                if (repeatDaysList.contains(dayOfWeekValue)) {
                    val candidateDateTime = candidateDate.atTime(alarm.hour, alarm.minute)
                    val candidateMillis = candidateDateTime.atZone(zoneId).toInstant().toEpochMilli()
                    if (candidateMillis > nowMillis) {
                        return candidateMillis
                    }
                }
            }
        }

        // 3. One-time Alarm (Today or Tomorrow)
        val todayDateTime = now.toLocalDate().atTime(alarm.hour, alarm.minute)
        val todayMillis = todayDateTime.atZone(zoneId).toInstant().toEpochMilli()
        return if (todayMillis > nowMillis) {
            todayMillis
        } else {
            val tomorrowDateTime = now.toLocalDate().plusDays(1).atTime(alarm.hour, alarm.minute)
            tomorrowDateTime.atZone(zoneId).toInstant().toEpochMilli()
        }
    }

    fun parseRepeatDays(repeatDays: String): Set<Int> {
        if (repeatDays.isBlank()) return emptySet()
        return repeatDays.split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it in 1..7 }
            .toSet()
    }

    fun formatRepeatDays(days: Set<Int>): String {
        return days.sorted().joinToString(",")
    }

    fun getRepeatDaysSummary(repeatDays: String, specificDate: String? = null): String {
        if (!specificDate.isNullOrBlank()) {
            return "On $specificDate"
        }
        val days = parseRepeatDays(repeatDays)
        if (days.isEmpty()) return "Once"
        if (days.size == 7) return "Every day"
        if (days == setOf(1, 2, 3, 4, 5)) return "Weekdays"
        if (days == setOf(6, 7)) return "Weekends"

        val dayNames = mapOf(
            1 to "Mon", 2 to "Tue", 3 to "Wed", 4 to "Thu",
            5 to "Fri", 6 to "Sat", 7 to "Sun"
        )
        return days.sorted().joinToString(", ") { dayNames[it] ?: "" }
    }
}
