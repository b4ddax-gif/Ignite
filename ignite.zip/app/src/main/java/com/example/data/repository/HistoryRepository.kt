package com.example.data.repository

import com.example.data.database.AlarmHistoryDao
import com.example.data.database.AlarmHistoryEntity
import com.example.data.database.StreakDao
import com.example.data.database.StreakEntity
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class HistoryRepository(
    private val historyDao: AlarmHistoryDao,
    private val streakDao: StreakDao
) {
    val allHistory: Flow<List<AlarmHistoryEntity>> = historyDao.getAllHistoryFlow()

    fun getHistorySince(sinceDate: String): Flow<List<AlarmHistoryEntity>> =
        historyDao.getHistorySinceFlow(sinceDate)

    suspend fun insertHistory(history: AlarmHistoryEntity): Long =
        historyDao.insertHistory(history)

    suspend fun clearAllHistory() =
        historyDao.clearAllHistory()

    val streakFlow: Flow<StreakEntity?> = streakDao.getStreakFlow()

    suspend fun recordAlarmDismissed(
        alarmId: Long,
        alarmLabel: String,
        scheduledDate: String,
        scheduledTime: String,
        snoozeCount: Int,
        dismissMethod: String
    ) {
        val now = System.currentTimeMillis()
        historyDao.insertHistory(
            AlarmHistoryEntity(
                alarmId = alarmId,
                alarmLabel = alarmLabel,
                scheduledDate = scheduledDate,
                scheduledTime = scheduledTime,
                dismissedAt = now,
                snoozeCount = snoozeCount,
                dismissMethod = dismissMethod,
                action = "DISMISSED"
            )
        )

        // Update streak
        val currentStreakEntity = streakDao.getStreak() ?: StreakEntity()
        val today = LocalDate.now()
        val todayStr = today.toString()

        val lastDateStr = currentStreakEntity.lastWakeDate
        var newCurrentStreak = currentStreakEntity.currentStreak
        var newLongestStreak = currentStreakEntity.longestStreak

        if (lastDateStr == null) {
            newCurrentStreak = 1
        } else {
            val lastDate = runCatching { LocalDate.parse(lastDateStr) }.getOrNull()
            if (lastDate != null) {
                val daysBetween = ChronoUnit.DAYS.between(lastDate, today)
                if (daysBetween == 1L) {
                    // Consecutive day
                    newCurrentStreak += 1
                } else if (daysBetween > 1L) {
                    // Broken streak
                    newCurrentStreak = 1
                }
                // If daysBetween == 0L, same day dismiss, streak stays same
            } else {
                newCurrentStreak = 1
            }
        }

        if (newCurrentStreak > newLongestStreak) {
            newLongestStreak = newCurrentStreak
        }

        val updatedStreak = currentStreakEntity.copy(
            currentStreak = newCurrentStreak,
            longestStreak = newLongestStreak,
            totalAlarmsCompleted = currentStreakEntity.totalAlarmsCompleted + 1,
            lastWakeDate = todayStr
        )
        streakDao.insertOrUpdateStreak(updatedStreak)
    }

    suspend fun recordAlarmSnoozed(
        alarmId: Long,
        alarmLabel: String,
        scheduledDate: String,
        scheduledTime: String,
        snoozeCount: Int
    ) {
        historyDao.insertHistory(
            AlarmHistoryEntity(
                alarmId = alarmId,
                alarmLabel = alarmLabel,
                scheduledDate = scheduledDate,
                scheduledTime = scheduledTime,
                dismissedAt = System.currentTimeMillis(),
                snoozeCount = snoozeCount,
                dismissMethod = "SNOOZE",
                action = "SNOOZED"
            )
        )
    }
}
