package com.example

import com.example.alarm.AlarmTimeCalculator
import com.example.calendar.CalendarScheduler
import com.example.data.database.AlarmEntity
import com.example.data.database.CalendarEventEntity
import com.example.data.database.StreakEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.temporal.ChronoUnit

class IgniteLogicTest {

    @Test
    fun testOneTimeAlarmLaterToday() {
        val zoneId = ZoneId.systemDefault()
        val fixedNow = LocalDate.of(2026, 10, 1).atTime(6, 0).atZone(zoneId).toInstant().toEpochMilli()

        val alarm = AlarmEntity(hour = 7, minute = 30) // 7:30 AM today
        val nextTrigger = AlarmTimeCalculator.calculateNextTriggerTime(alarm, fixedNow)

        val triggerDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(nextTrigger), zoneId)
        assertEquals(2026, triggerDateTime.year)
        assertEquals(10, triggerDateTime.monthValue)
        assertEquals(1, triggerDateTime.dayOfMonth)
        assertEquals(7, triggerDateTime.hour)
        assertEquals(30, triggerDateTime.minute)
    }

    @Test
    fun testOneTimeAlarmEarlierTodayRingsTomorrow() {
        val zoneId = ZoneId.systemDefault()
        val fixedNow = LocalDate.of(2026, 10, 1).atTime(9, 0).atZone(zoneId).toInstant().toEpochMilli()

        val alarm = AlarmEntity(hour = 7, minute = 0) // 7:00 AM was earlier today
        val nextTrigger = AlarmTimeCalculator.calculateNextTriggerTime(alarm, fixedNow)

        val triggerDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(nextTrigger), zoneId)
        assertEquals(2, triggerDateTime.dayOfMonth) // Tomorrow!
        assertEquals(7, triggerDateTime.hour)
        assertEquals(0, triggerDateTime.minute)
    }

    @Test
    fun testDateSpecificAlarmFuture() {
        val zoneId = ZoneId.systemDefault()
        val fixedNow = LocalDate.of(2026, 10, 1).atTime(6, 0).atZone(zoneId).toInstant().toEpochMilli()

        val alarm = AlarmEntity(
            hour = 7,
            minute = 0,
            specificDate = "2026-12-25"
        )
        val nextTrigger = AlarmTimeCalculator.calculateNextTriggerTime(alarm, fixedNow)

        val triggerDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(nextTrigger), zoneId)
        assertEquals(2026, triggerDateTime.year)
        assertEquals(12, triggerDateTime.monthValue)
        assertEquals(25, triggerDateTime.dayOfMonth)
        assertEquals(7, triggerDateTime.hour)
    }

    @Test
    fun testDateSpecificAlarmPastReturnsNegative() {
        val zoneId = ZoneId.systemDefault()
        val fixedNow = LocalDate.of(2026, 12, 26).atTime(6, 0).atZone(zoneId).toInstant().toEpochMilli()

        val alarm = AlarmEntity(
            hour = 7,
            minute = 0,
            specificDate = "2026-12-25"
        )
        val nextTrigger = AlarmTimeCalculator.calculateNextTriggerTime(alarm, fixedNow)
        assertEquals(-1L, nextTrigger)
    }

    @Test
    fun testRepeatDaysSummary() {
        assertEquals("Every day", AlarmTimeCalculator.getRepeatDaysSummary("1,2,3,4,5,6,7"))
        assertEquals("Weekdays", AlarmTimeCalculator.getRepeatDaysSummary("1,2,3,4,5"))
        assertEquals("Weekends", AlarmTimeCalculator.getRepeatDaysSummary("6,7"))
        assertEquals("Once", AlarmTimeCalculator.getRepeatDaysSummary(""))
        assertEquals("On 2026-12-25", AlarmTimeCalculator.getRepeatDaysSummary("1,2", "2026-12-25"))
    }

    @Test
    fun testCalendarReminderTimeCalculation() {
        val event = CalendarEventEntity(
            title = "Team Meeting",
            date = "2026-10-15",
            startTime = "14:00",
            reminder = "15_MIN"
        )

        val reminderTime = CalendarScheduler.calculateReminderTime(event)
        val zoneId = ZoneId.systemDefault()
        val reminderDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(reminderTime), zoneId)

        assertEquals(13, reminderDateTime.hour)
        assertEquals(45, reminderDateTime.minute)
    }

    @Test
    fun testStreakLogic() {
        // First wake
        var streak = StreakEntity(currentStreak = 0, longestStreak = 0, totalAlarmsCompleted = 0)
        val today = LocalDate.of(2026, 10, 1)

        val updatedStreak1 = streak.copy(
            currentStreak = 1,
            longestStreak = 1,
            totalAlarmsCompleted = 1,
            lastWakeDate = today.toString()
        )
        assertEquals(1, updatedStreak1.currentStreak)

        // Consecutive day
        val tomorrow = today.plusDays(1)
        val daysBetween = ChronoUnit.DAYS.between(LocalDate.parse(updatedStreak1.lastWakeDate), tomorrow)
        assertEquals(1L, daysBetween)

        val updatedStreak2 = updatedStreak1.copy(
            currentStreak = updatedStreak1.currentStreak + 1,
            longestStreak = maxOf(updatedStreak1.longestStreak, updatedStreak1.currentStreak + 1),
            totalAlarmsCompleted = updatedStreak1.totalAlarmsCompleted + 1,
            lastWakeDate = tomorrow.toString()
        )
        assertEquals(2, updatedStreak2.currentStreak)
        assertEquals(2, updatedStreak2.longestStreak)
        assertEquals(2, updatedStreak2.totalAlarmsCompleted)

        // Broken streak (3 days later)
        val future = tomorrow.plusDays(3)
        val brokenDays = ChronoUnit.DAYS.between(LocalDate.parse(updatedStreak2.lastWakeDate), future)
        assertTrue(brokenDays > 1)

        val updatedStreak3 = updatedStreak2.copy(
            currentStreak = 1,
            longestStreak = updatedStreak2.longestStreak,
            totalAlarmsCompleted = updatedStreak2.totalAlarmsCompleted + 1,
            lastWakeDate = future.toString()
        )
        assertEquals(1, updatedStreak3.currentStreak)
        assertEquals(2, updatedStreak3.longestStreak)
        assertEquals(3, updatedStreak3.totalAlarmsCompleted)
    }
}
