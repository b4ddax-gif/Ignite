package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wake_streak")
data class StreakEntity(
    @PrimaryKey
    val id: Int = 1,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val totalAlarmsCompleted: Int = 0,
    val lastWakeDate: String? = null // "yyyy-MM-dd"
)
