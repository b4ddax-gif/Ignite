package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "calendar_events")
data class CalendarEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val date: String, // "yyyy-MM-dd"
    val startTime: String = "09:00", // "HH:mm"
    val endTime: String = "10:00", // "HH:mm"
    val allDay: Boolean = false,
    val reminder: String = "AT_TIME", // NONE, AT_TIME, 5_MIN, 10_MIN, 15_MIN, 30_MIN, 1_HOUR, 1_DAY
    val repeatRule: String = "NONE", // NONE, DAILY, WEEKLY, MONTHLY, YEARLY
    val important: Boolean = false, // Starred for countdown
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
