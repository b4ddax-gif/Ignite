package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alarm_history")
data class AlarmHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val alarmId: Long,
    val alarmLabel: String,
    val scheduledDate: String, // "yyyy-MM-dd"
    val scheduledTime: String, // "HH:mm"
    val dismissedAt: Long,
    val snoozeCount: Int = 0,
    val dismissMethod: String = "NORMAL", // NORMAL, MATH, SHAKE, QR
    val action: String = "DISMISSED" // DISMISSED, SNOOZED
)
