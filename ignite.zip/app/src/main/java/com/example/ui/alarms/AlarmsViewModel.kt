package com.example.ui.alarms

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.IgniteApplication
import com.example.alarm.AlarmScheduler
import com.example.alarm.AlarmTimeCalculator
import com.example.data.database.AlarmEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AlarmsUiState(
    val alarms: List<AlarmEntity> = emptyList(),
    val is24Hour: Boolean = false,
    val canScheduleExactAlarms: Boolean = true
)

class AlarmsViewModel : ViewModel() {

    private val app = IgniteApplication.instance
    private val alarmRepo = app.alarmRepository
    private val settingsRepo = app.settingsRepository
    private val alarmScheduler = app.alarmScheduler

    val uiState: StateFlow<AlarmsUiState> = combine(
        alarmRepo.allAlarms,
        settingsRepo.is24Hour
    ) { alarms, is24Hour ->
        AlarmsUiState(
            alarms = alarms,
            is24Hour = is24Hour,
            canScheduleExactAlarms = alarmScheduler.canScheduleExactAlarms()
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AlarmsUiState()
    )

    fun toggleAlarm(alarm: AlarmEntity, enabled: Boolean) {
        viewModelScope.launch {
            val updated = alarm.copy(enabled = enabled, updatedAt = System.currentTimeMillis())
            alarmRepo.updateAlarm(updated)
            if (enabled) {
                alarmScheduler.scheduleAlarm(updated)
            } else {
                alarmScheduler.cancelAlarm(alarm.id)
            }
        }
    }

    fun deleteAlarm(alarm: AlarmEntity) {
        viewModelScope.launch {
            alarmScheduler.cancelAlarm(alarm.id)
            alarmRepo.deleteAlarm(alarm)
        }
    }

    fun saveAlarm(alarm: AlarmEntity, onSaved: () -> Unit) {
        viewModelScope.launch {
            if (alarm.id == 0L) {
                val newId = alarmRepo.insertAlarm(alarm)
                val inserted = alarm.copy(id = newId)
                if (inserted.enabled) {
                    alarmScheduler.scheduleAlarm(inserted)
                }
            } else {
                alarmRepo.updateAlarm(alarm)
                if (alarm.enabled) {
                    alarmScheduler.scheduleAlarm(alarm)
                } else {
                    alarmScheduler.cancelAlarm(alarm.id)
                }
            }
            onSaved()
        }
    }
}
